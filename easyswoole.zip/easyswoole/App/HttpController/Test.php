<?php

namespace App\HttpController;

use App\Utility\ViewController;
use \think\Db;

/**
 * Class Index
 * @author  : evalor <master@evalor.cn>
 * @package App\HttpController
 */
class Test extends ViewController
{
    function index()
    {
         
       $user=Db::table('user')
    ->where('id','<',10)
    ->order('id','desc')
    ->limit(10)
    ->select();
        print_r($user);

          $this->assign("user",$user);
        // Smarty
        $this->fetch('index.html'); # 对应模板: Views/index.html
    }
}
