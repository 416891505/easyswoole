<?php
/**
 * Created by PhpStorm.
 * User: yf
 * Date: 2018/3/3
 * Time: 下午6:47
 */

namespace App\Model;


use App\Utility\Db;

class Model extends Db
{

}
