<?php

return [
        'type'            => 'mysql',
        'hostname'        => '127.0.0.1',
        'database'        => 'es-admin',
        'username'        => 'root',
        'password'        => 'dusy92.',
        'hostport'        => '3306',
        'prefix'          => 'es_',
        'break_reconnect' => true,
];