<?php
/**
 * Created by PhpStorm.
 * User: yf
 * Date: 2018/3/5
 * Time: 下午10:36
 */
namespace App\Utility;
class SysConst
{
    const COOKIE_USER_SESSION_NAME = 'userSession';
    const COOKIE_USER_SESSION_TTL = 24*3600;//一天
}